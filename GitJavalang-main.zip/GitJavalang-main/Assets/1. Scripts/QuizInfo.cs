using UnityEngine;

public class QuestionInfo : MonoBehaviour
{
    public GameObject TrueInfo;
    public GameObject FalseInfo;
}
